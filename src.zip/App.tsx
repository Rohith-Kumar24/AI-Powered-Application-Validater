import { useMemo, useState } from 'react'

type Page = 'dashboard' | 'applications' | 'new' | 'document' | 'compliance' | 'risk' | 'reports' | 'audit' | 'settings'
type Tone = 'success' | 'warning' | 'danger' | 'info' | 'neutral'

const paths: Record<string, string> = {
  grid: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
  files: 'M14 2H6a2 2 0 0 0-2 2v16h14V6zM14 2v4h4M8 11h6M8 15h6',
  scan: 'M3 8V5a2 2 0 0 1 2-2h3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M8 21H5a2 2 0 0 1-2-2v-3M8 12h8',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9 12l2 2 4-4',
  brain: 'M9.5 4.5A3 3 0 0 0 4 6v1a3 3 0 0 0-1 5 3 3 0 0 0 2 5 3 3 0 0 0 4.5 2.5M14.5 4.5A3 3 0 0 1 20 6v1a3 3 0 0 1 1 5 3 3 0 0 1-2 5 3 3 0 0 1-4.5 2.5M12 4v16M8 9h4M12 15h4',
  chart: 'M4 19V9M10 19V5M16 19v-7M22 19H2',
  clock: 'M12 8v4l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z',
  settings: 'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21h-4v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3v-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.5V3h4v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.5 1h.1v4h-.1a1.7 1.7 0 0 0-1.5 1z',
  search: 'M21 21l-4.3-4.3M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0z',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4',
  help: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM9.5 9a2.5 2.5 0 1 1 3.2 2.4c-.7.3-.7 1.1-.7 1.6M12 17h.01',
  plus: 'M12 5v14M5 12h14',
  chevron: 'M9 18l6-6-6-6',
  filter: 'M4 5h16M7 12h10M10 19h4',
  upload: 'M12 16V4M7 9l5-5 5 5M4 20h16',
  check: 'M5 12l4 4L19 6',
  x: 'M18 6L6 18M6 6l12 12',
  eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  download: 'M12 3v12M7 10l5 5 5-5M4 21h16',
  alert: 'M12 9v4M12 17h.01M10.3 3.6 2.2 18h19.6L13.7 3.6a2 2 0 0 0-3.4 0z',
  more: 'M5 12h.01M12 12h.01M19 12h.01',
  user: 'M20 21a8 8 0 0 0-16 0M12 13a5 5 0 1 0 0-10 5 5 0 0 0 0 10z',
  lock: 'M5 10h14v11H5zM8 10V7a4 4 0 0 1 8 0v3',
}

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name] || paths.grid} /></svg>
}

function Button({ children, tone = 'primary', icon, onClick, disabled = false }: { children: React.ReactNode; tone?: 'primary' | 'secondary' | 'danger' | 'ghost'; icon?: string; onClick?: () => void; disabled?: boolean }) {
  return <button className={`btn btn-${tone}`} onClick={onClick} disabled={disabled}>{icon && <Icon name={icon} size={16} />}{children}</button>
}

function Badge({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: Tone }) {
  return <span className={`badge badge-${tone}`}><span className="badge-dot" />{children}</span>
}

function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <section className={`card ${className}`}>{children}</section>
}

const nav: { id: Page; label: string; icon: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: 'grid' },
  { id: 'applications', label: 'Applications', icon: 'files' },
  { id: 'document', label: 'Document Verification', icon: 'scan' },
  { id: 'compliance', label: 'Compliance Center', icon: 'shield' },
  { id: 'risk', label: 'AI Risk Analysis', icon: 'brain' },
  { id: 'reports', label: 'Reports & Analytics', icon: 'chart' },
  { id: 'audit', label: 'Audit Trail', icon: 'clock' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
]

const applications = [
  { id: 'APP-2025-1284', name: 'Maya Patel', initials: 'MP', category: 'Vendor Onboarding', date: 'May 24, 2025', status: 'Verified', risk: 'Low' },
  { id: 'APP-2025-1283', name: 'Ethan Williams', initials: 'EW', category: 'Business License', date: 'May 24, 2025', status: 'Pending', risk: 'Medium' },
  { id: 'APP-2025-1282', name: 'Olivia Chen', initials: 'OC', category: 'Identity Review', date: 'May 23, 2025', status: 'Flagged', risk: 'High' },
  { id: 'APP-2025-1281', name: 'Noah Thompson', initials: 'NT', category: 'Grant Application', date: 'May 23, 2025', status: 'Verified', risk: 'Low' },
  { id: 'APP-2025-1280', name: 'Sophia Rodriguez', initials: 'SR', category: 'Vendor Onboarding', date: 'May 22, 2025', status: 'Pending', risk: 'Medium' },
  { id: 'APP-2025-1279', name: 'Liam Anderson', initials: 'LA', category: 'Business License', date: 'May 22, 2025', status: 'Rejected', risk: 'High' },
]

function PageHeader({ title, subtitle, children }: { title: string; subtitle: string; children?: React.ReactNode }) {
  return <div className="page-header"><div><h1>{title}</h1><p>{subtitle}</p></div>{children && <div className="header-actions">{children}</div>}</div>
}

function SearchBox({ placeholder = 'Search...' }: { placeholder?: string }) {
  return <label className="search"><Icon name="search" size={17} /><input placeholder={placeholder} /></label>
}

function ApplicationTable({ onOpen, compact = false }: { onOpen: (id: string) => void; compact?: boolean }) {
  const rows = compact ? applications.slice(0, 5) : applications
  return <div className="table-wrap"><table><thead><tr><th>Application ID</th><th>Applicant</th><th>Category</th><th>Submitted</th><th>Status</th><th>Risk</th><th>Action</th></tr></thead><tbody>
    {rows.map(a => <tr key={a.id} onClick={() => onOpen(a.id)} className="click-row"><td className="id-cell">{a.id}</td><td><div className="person"><span className="avatar-sm">{a.initials}</span><strong>{a.name}</strong></div></td><td>{a.category}</td><td>{a.date}</td><td><Badge tone={a.status === 'Verified' ? 'success' : a.status === 'Pending' ? 'warning' : 'danger'}>{a.status}</Badge></td><td><Badge tone={a.risk === 'Low' ? 'success' : a.risk === 'Medium' ? 'warning' : 'danger'}>{a.risk}</Badge></td><td><button className="table-action" onClick={(e) => { e.stopPropagation(); onOpen(a.id) }}>View details <Icon name="chevron" size={14} /></button></td></tr>)}
  </tbody></table></div>
}

function Dashboard({ navigate, openApplication }: { navigate: (p: Page) => void; openApplication: (id: string) => void }) {
  const kpis = [
    ['files', 'Total Applications', '1,284', '+12.5%', 'All applications submitted'],
    ['shield', 'Verified Applications', '936', '+8.2%', 'Successfully verified'],
    ['clock', 'Pending Reviews', '218', '-3.1%', 'Awaiting analyst review'],
    ['alert', 'Flagged Documents', '47', '+2.4%', 'Require manual attention'],
    ['check', 'Compliance Rate', '92.4%', '+1.8%', 'Across all requirements'],
    ['brain', 'High-Risk Cases', '18', '-7.3%', 'Urgent review required'],
  ]
  return <><PageHeader title="Verification Overview" subtitle="Monitor applications, document authenticity, and compliance status."><Button icon="plus" onClick={() => navigate('new')}>New Application</Button></PageHeader>
    <div className="welcome"><div><span className="eyebrow">MONDAY, MAY 26</span><h2>Good morning, Alex</h2><p>Here’s what’s happening across your verification workspace today.</p></div><div className="welcome-stat"><span>Platform status</span><strong><i /> All systems operational</strong></div></div>
    <div className="kpi-grid">{kpis.map((k, i) => <Card className="kpi" key={k[1]}><div className={`kpi-icon i-${i}`}><Icon name={k[0]} /></div><div className="kpi-top"><span>{k[1]}</span><b className={k[3].startsWith('-') && i !== 2 && i !== 5 ? 'negative' : ''}>{k[3]}</b></div><strong className="metric">{k[2]}</strong><p>{k[4]}</p></Card>)}</div>
    <div className="dashboard-grid">
      <Card className="trend-card"><CardTitle title="Application Processing Trends" subtitle="Received vs. verified in the last 7 days" action="Last 7 days" /><div className="legend"><span><i className="dot blue" />Received</span><span><i className="dot cyan" />Verified</span></div><LineChart /></Card>
      <Card><CardTitle title="Verification Status" subtitle="Current distribution" /><Donut value="73%" /><div className="chart-list"><div><span><i className="dot green" />Verified</span><b>936</b></div><div><span><i className="dot amber" />Pending</span><b>218</b></div><div><span><i className="dot red" />Failed</span><b>130</b></div></div></Card>
      <Card><CardTitle title="Risk Distribution" subtitle="Across active applications" /><div className="bar-chart"><Bar label="Low risk" value={72} count="924" tone="green" /><Bar label="Medium risk" value={21} count="269" tone="amber" /><Bar label="High risk" value={7} count="91" tone="red" /></div></Card>
    </div>
    <div className="lower-grid"><Card className="table-card"><CardTitle title="Recent Applications" subtitle="Latest application activity" action="View all" onAction={() => navigate('applications')} /><ApplicationTable compact onOpen={openApplication} /></Card>
      <Card className="activity"><CardTitle title="Recent Activity" subtitle="Latest verification events" />{[
        ['check', 'Application verified', 'Maya Patel · APP-2025-1284', '12 min ago', 'success'],
        ['alert', 'Document inconsistency found', 'Olivia Chen · APP-2025-1282', '34 min ago', 'danger'],
        ['upload', 'New documents uploaded', 'Ethan Williams · APP-2025-1283', '1 hr ago', 'info'],
        ['shield', 'Compliance review passed', 'Noah Thompson · APP-2025-1281', '2 hrs ago', 'success'],
      ].map((x, i) => <div className="activity-row" key={i}><span className={`activity-icon ${x[4]}`}><Icon name={x[0]} size={15} /></span><div><strong>{x[1]}</strong><p>{x[2]}</p><small>{x[3]}</small></div></div>)}</Card></div>
  </>
}

function CardTitle({ title, subtitle, action, onAction }: { title: string; subtitle?: string; action?: string; onAction?: () => void }) {
  return <div className="card-title"><div><h3>{title}</h3>{subtitle && <p>{subtitle}</p>}</div>{action && <button onClick={onAction}>{action} <Icon name="chevron" size={13} /></button>}</div>
}

function LineChart() {
  return <div className="line-chart"><div className="y-labels"><span>240</span><span>180</span><span>120</span><span>60</span><span>0</span></div><svg viewBox="0 0 700 210" preserveAspectRatio="none"><defs><linearGradient id="area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#3563e9" stopOpacity=".16" /><stop offset="1" stopColor="#3563e9" stopOpacity="0" /></linearGradient></defs><g className="gridlines"><path d="M0 10H700M0 58H700M0 106H700M0 154H700M0 202H700" /></g><path className="area" d="M0 170L115 130L230 145L350 80L465 105L580 42L700 65V210H0z" /><path className="line-a" d="M0 170L115 130L230 145L350 80L465 105L580 42L700 65" /><path className="line-b" d="M0 188L115 158L230 168L350 115L465 130L580 76L700 92" />{[[0,170],[115,130],[230,145],[350,80],[465,105],[580,42],[700,65]].map((p,i)=><circle key={i} cx={p[0]} cy={p[1]} r="4" className="point" />)}</svg><div className="x-labels"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div></div>
}

function Donut({ value, label = 'Verified' }: { value: string; label?: string }) {
  return <div className="donut" style={{ '--value': value } as React.CSSProperties}><div><strong>{value}</strong><span>{label}</span></div></div>
}
function Bar({ label, value, count, tone }: { label: string; value: number; count: string; tone: string }) {
  return <div className="bar-row"><div><span>{label}</span><b>{count}</b></div><div className="bar-track"><i className={tone} style={{ width: `${value}%` }} /></div><small>{value}% of total</small></div>
}

function Applications({ navigate, openApplication }: { navigate: (p: Page) => void; openApplication: (id: string) => void }) {
  const [tab, setTab] = useState('All')
  return <><PageHeader title="Applications" subtitle="Manage, review, and track all submitted applications."><Button icon="plus" onClick={() => navigate('new')}>New Application</Button></PageHeader>
    <Card className="toolbar-card"><div className="toolbar"><SearchBox placeholder="Search applicant or application ID..." /><div className="filters"><button><Icon name="filter" size={16} /> Status</button><button>Category <Icon name="chevron" size={13} /></button><button>Date range <Icon name="chevron" size={13} /></button><button>Risk level <Icon name="chevron" size={13} /></button></div></div>
      <div className="tabs">{['All', 'Pending', 'Verified', 'Flagged', 'Rejected'].map((t, i) => <button className={tab === t ? 'active' : ''} onClick={() => setTab(t)} key={t}>{t}<span>{[1284,218,936,47,83][i]}</span></button>)}</div>
    </Card>
    <Card className="table-card applications-card"><div className="table-summary"><span>Showing <strong>1–6</strong> of <strong>1,284</strong> applications</span><button><Icon name="download" size={16} /> Export</button></div><ApplicationTable onOpen={openApplication} /><div className="pagination"><span>Rows per page: <strong>10</strong></span><div><button disabled>‹</button><button className="active">1</button><button>2</button><button>3</button><span>…</span><button>129</button><button>›</button></div></div></Card>
  </>
}

function ApplicationDetail({ id, onBack, notify }: { id: string; onBack: () => void; notify: (s: string) => void }) {
  const [tab, setTab] = useState('Overview')
  return <><button className="back" onClick={onBack}>← Back to applications</button><PageHeader title={id} subtitle="Vendor onboarding application · Submitted May 24, 2025"><div className="header-actions"><Button tone="secondary" onClick={() => notify('Changes requested from applicant')}>Request Changes</Button><Button tone="danger" onClick={() => notify('Application rejected')}>Reject</Button><Button icon="check" onClick={() => notify('Application approved successfully')}>Approve</Button></div></PageHeader>
    <div className="detail-banner"><div className="person"><span className="avatar-lg">MP</span><div><h2>Maya Patel</h2><p>maya.patel@novacore.in · +91 98765 43210</p></div></div><div className="banner-stats"><div><span>Status</span><Badge tone="warning">Pending review</Badge></div><div><span>Risk level</span><Badge tone="success">Low risk</Badge></div><div><span>Compliance</span><b>92%</b></div></div></div>
    <div className="tabs detail-tabs">{['Overview','Documents','Validation Results','Activity'].map(t=><button className={tab===t?'active':''} onClick={()=>setTab(t)} key={t}>{t}</button>)}</div>
    <div className="detail-grid"><div className="stack">
      <Card><CardTitle title="Applicant Information" action="Edit" /><div className="info-grid"><Info label="Full name" value="Maya Patel" /><Info label="Organization" value="Novacore Systems Pvt. Ltd." /><Info label="Email address" value="maya.patel@novacore.in" /><Info label="Phone number" value="+91 98765 43210" /><Info label="Application category" value="Vendor Onboarding" /><Info label="Submission date" value="May 24, 2025, 10:32 AM" /></div></Card>
      <Card><CardTitle title="Document Checklist" subtitle="4 of 4 required documents uploaded" />{['Government ID · Aadhaar Card','Address Proof · Utility Bill','Business Registration Certificate','Tax Identification Document'].map((d,i)=><div className="doc-row" key={d}><span className="file-icon"><Icon name="files" /></span><div><strong>{d}</strong><p>PDF · {i+1}.2 MB · Verified May 24</p></div><Badge tone={i===1?'warning':'success'}>{i===1?'Review':'Verified'}</Badge><button><Icon name="eye" /></button></div>)}</Card>
      <Card><CardTitle title="Reviewer Notes" /><textarea className="textarea" placeholder="Add an internal note for the review team..." /><div className="note-footer"><small>Only visible to your organization</small><Button tone="secondary" onClick={() => notify('Reviewer note saved')}>Save note</Button></div></Card>
    </div><div className="stack">
      <Card><CardTitle title="Validation Summary" /><div className="score-ring"><Donut value="94%" label="Confidence" /></div>{['Identity information matched','Documents appear authentic','Address requires manual review','No duplicate application found'].map((x,i)=><div className="checkline" key={x}><span className={i===2?'warn':'pass'}><Icon name={i===2?'alert':'check'} size={14}/></span>{x}</div>)}<Button onClick={() => notify('Validation completed with 94% confidence')} icon="scan">Run Validation</Button></Card>
      <Card><CardTitle title="Risk Assessment" /><div className="risk-score"><span>Overall risk</span><strong>24<small>/100</small></strong><Badge tone="success">Low risk</Badge></div><div className="mini-meter"><i /></div><p className="muted">No critical risk factors detected. One address discrepancy should be reviewed.</p></Card>
      <Card><CardTitle title="Compliance Status" /><div className="compliance-mini"><strong>11/12</strong><span>checks passed</span></div><div className="progress"><i style={{width:'92%'}} /></div><button className="text-link">View compliance details <Icon name="chevron" size={13}/></button></Card>
    </div></div>
  </>
}

function Info({ label, value }: { label: string; value: string }) { return <div className="info"><span>{label}</span><strong>{value}</strong></div> }

function NewApplication({ navigate, notify }: { navigate: (p: Page) => void; notify: (s: string) => void }) {
  const [step, setStep] = useState(1)
  const [files, setFiles] = useState<number[]>([0,1])
  if (step === 4) return <div className="success-page"><div className="success-mark"><Icon name="check" size={38}/></div><span className="eyebrow">APPLICATION SUBMITTED</span><h1>Application created successfully</h1><p>Your application has been securely submitted and is ready for verification.</p><Card><span>Application ID</span><strong>APP-2025-1285</strong><small>Keep this ID for future reference</small></Card><Button onClick={()=>navigate('dashboard')}>Return to Dashboard</Button><Button tone="ghost" onClick={()=>navigate('applications')}>View Application</Button></div>
  return <><PageHeader title="New Application" subtitle="Create and submit a new application for verification." />
    <div className="stepper">{['Applicant Information','Document Upload','Review Information','Complete'].map((s,i)=><div className={`step ${step>i?'active':''}`} key={s}><span>{step>i+1?<Icon name="check" size={14}/>:i+1}</span><div><b>Step {i+1}</b><small>{s}</small></div></div>)}</div>
    <Card className="wizard-card">
      {step===1 && <><CardTitle title="Applicant Information" subtitle="Provide the applicant and application details." /><div className="form-grid"><Field label="Full Name" placeholder="Enter full legal name" value="Aarav Mehta" /><Field label="Email Address" placeholder="name@company.com" value="aarav@lumina.in" /><Field label="Phone Number" placeholder="+91 00000 00000" /><Field label="Organization" placeholder="Organization name" /><Field label="Application Category" select="Vendor Onboarding" /><Field label="Application Purpose" placeholder="Describe the purpose of this application" wide textarea /></div></>}
      {step===2 && <><CardTitle title="Upload Documents" subtitle="Upload clear, legible copies. PDF, PNG, or JPG up to 10 MB." /><div className="upload-grid">{['Identity Proof','Address Proof','Supporting Certificates','Additional Documents'].map((x,i)=><button className={`upload-card ${files.includes(i)?'uploaded':''}`} onClick={()=>setFiles(f=>f.includes(i)?f:[...f,i])} key={x}>{files.includes(i)?<><span className="upload-file"><Icon name="files"/><i><Icon name="check" size={12}/></i></span><strong>{i===0?'aadhaar_card.pdf':'address_proof.pdf'}</strong><small>1.8 MB · Upload complete</small><div className="upload-progress"><i /></div></>:<><span className="upload-icon"><Icon name="upload"/></span><strong>{x}</strong><small>Drag and drop or <b>browse files</b></small><em>PDF, PNG, JPG · Max 10 MB</em></>}</button>)}</div></>}
      {step===3 && <><CardTitle title="Review Information" subtitle="Confirm all details are correct before submitting." /><div className="review-section"><div className="review-heading"><h3>Applicant Information</h3><button onClick={()=>setStep(1)}>Edit</button></div><div className="info-grid"><Info label="Full name" value="Aarav Mehta"/><Info label="Email address" value="aarav@lumina.in"/><Info label="Organization" value="Lumina Technologies"/><Info label="Category" value="Vendor Onboarding"/></div></div><div className="review-section"><div className="review-heading"><h3>Uploaded Documents</h3><button onClick={()=>setStep(2)}>Edit</button></div>{['aadhaar_card.pdf','address_proof.pdf'].map(f=><div className="doc-row" key={f}><span className="file-icon"><Icon name="files"/></span><div><strong>{f}</strong><p>PDF · Upload complete</p></div><Badge tone="success">Ready</Badge></div>)}</div><label className="consent"><input type="checkbox" defaultChecked/><span>I confirm that the information provided is accurate and I have consent to submit these documents for verification.</span></label></>}
      <div className="wizard-footer"><Button tone="secondary" onClick={()=>step===1?navigate('applications'):setStep(step-1)}> {step===1?'Cancel':'Back'} </Button><Button onClick={()=>{if(step===3){notify('Application submitted');setStep(4)}else setStep(step+1)}}>{step===3?'Submit Application':'Continue'} <span>→</span></Button></div>
    </Card></>
}

function Field({ label, placeholder, value, select, wide, textarea }: { label:string; placeholder?:string; value?:string; select?:string; wide?:boolean; textarea?:boolean }) {
  return <label className={`field ${wide?'wide':''}`}><span>{label}</span>{select?<select defaultValue={select}><option>{select}</option><option>Business License</option><option>Identity Review</option></select>:textarea?<textarea placeholder={placeholder}/>:<input placeholder={placeholder} defaultValue={value}/>}</label>
}

function DocumentVerification({ notify }: { notify:(s:string)=>void }) {
  const [running,setRunning]=useState(false); const [expanded,setExpanded]=useState('Detected Inconsistencies')
  const run=()=>{setRunning(true); setTimeout(()=>{setRunning(false);notify('Verification completed — manual review recommended')},1400)}
  return <><PageHeader title="Document Verification" subtitle="Analyze uploaded documents and review AI-assisted verification findings."><Badge tone="info">Simulated demonstration results</Badge></PageHeader>
    <div className="verification-grid"><Card className="document-panel"><div className="panel-heading"><div><h3>Document Preview</h3><p>aadhaar_card_maya.pdf · Identity Proof</p></div><Button tone="secondary" icon="upload">Replace</Button></div><div className="preview-toolbar"><span>Page 1 of 1</span><div><button>−</button><strong>100%</strong><button>+</button><button>↗</button></div></div><div className="document-preview"><div className="doc-paper"><div className="fake-gov"><span>GOVERNMENT OF INDIA</span><b>आधार</b></div><div className="fake-content"><div className="photo-placeholder"><Icon name="user" size={42}/></div><div><i/><i/><i className="short"/><strong>MAYA P. PATEL</strong><p>XXXX XXXX 4721</p></div></div><div className="fake-footer">Identity Document · Sample Preview</div></div></div><div className="ocr"><div className="ocr-head"><div><h3>Extracted OCR Text</h3><p>12 fields detected · 98.2% extraction confidence</p></div><Badge tone="success">Complete</Badge></div><pre>Name: MAYA P. PATEL{'\n'}Date of Birth: 12/08/1994{'\n'}ID Number: XXXX XXXX 4721{'\n'}Address: 14 Lakeview Road, Pune</pre></div></Card>
      <div className="analysis-stack"><Card className="analysis-card"><div className="analysis-head"><div><span className="eyebrow">AI ANALYSIS</span><h2>{running?'Analyzing document…':'Needs Manual Review'}</h2><p>{running?'Checking document integrity and cross-document data.':'One inconsistency requires an analyst decision.'}</p></div><div className={`confidence ${running?'spinning':''}`}><strong>{running?'…':'87%'}</strong><span>confidence</span></div></div>{running?<div className="analysis-progress"><i/><p>Running cross-document consistency checks…</p></div>:<div className="checks">{[['Document authenticity','Likely authentic','success'],['OCR extraction','Complete · 98.2%','success'],['Name matching','Mismatch detected','danger'],['Date validation','Valid','success'],['Cross-document consistency','Review needed','warning'],['File integrity','No issues','success']].map(x=><div key={x[0]}><span className={x[2]}><Icon name={x[2]==='success'?'check':x[2]==='danger'?'x':'alert'} size={14}/></span><p><strong>{x[0]}</strong><small>{x[1]}</small></p></div>)}</div>}<div className="issue-box"><Icon name="alert"/><div><strong>Name inconsistency detected</strong><p>“MAYA P. PATEL” on identity proof differs from “MAYA PRIYA PATEL” on the business certificate.</p></div></div><div className="recommendation"><span>Recommendation</span><p>Review the original documents and confirm the applicant’s full legal name before making a decision.</p></div></Card>
      <Card className="accordions">{['Extracted Information','Detected Inconsistencies','Verification Evidence','Recommended Actions'].map(x=><div className={`accordion ${expanded===x?'open':''}`} key={x}><button onClick={()=>setExpanded(expanded===x?'':x)}><span>{x}{x==='Detected Inconsistencies'&&<Badge tone="danger">1 issue</Badge>}</span><Icon name="chevron" size={15}/></button>{expanded===x&&<div className="accordion-body">{x==='Detected Inconsistencies'?<><strong>Legal name mismatch</strong><p>Identity document uses a middle initial while the supporting certificate contains the full middle name. This may be benign, but should be manually confirmed.</p></>:<p>Evidence captured from OCR, visual integrity checks, and cross-document field comparison. Review source files before deciding.</p>}</div>}</div>)}</Card>
      <div className="action-row"><Button onClick={run} icon="scan" disabled={running}>{running?'Running…':'Run Verification'}</Button><Button tone="secondary" onClick={()=>notify('Document marked as reviewed')}>Mark as Reviewed</Button><Button tone="ghost" onClick={()=>notify('New document request sent')}>Request New Document</Button></div></div>
    </div></>
}

function Compliance({ notify }: { notify:(s:string)=>void }) {
  const [framework,setFramework]=useState('India DPDP Readiness')
  const checks=[['Identity proof validated','Identity Verification','Passed','4 documents','May 24, 2025'],['Required fields complete','Application Completeness','Passed','18 fields','May 24, 2025'],['Consent record captured','Data Privacy and Consent','Warning','Consent v2.1','May 23, 2025'],['Retention schedule assigned','Document Retention','Failed','No policy','May 22, 2025'],['Reviewer separation of duties','Internal Policies','Passed','Audit record','May 24, 2025']]
  return <><PageHeader title="Compliance Center" subtitle="Review requirements, outstanding issues, and remediation actions."><select className="framework" value={framework} onChange={e=>setFramework(e.target.value)}><option>India DPDP Readiness</option><option>Global Privacy Baseline</option><option>Internal Vendor Policy</option></select><Button tone="secondary" icon="download">Export Report</Button></PageHeader>
    <div className="compliance-hero"><Card className="score-card"><div><span className="eyebrow">OVERALL COMPLIANCE SCORE</span><h2>Strong compliance posture</h2><p>Based on 50 automated and manual checks in the selected framework.</p><div className="score-breakdown"><div><i className="green"/><span>Passed Checks<b>42</b></span></div><div><i className="amber"/><span>Warnings<b>5</b></span></div><div><i className="red"/><span>Failed Checks<b>3</b></span></div></div></div><Donut value="92.4%" label="compliant"/></Card>
      <Card className="priority-card"><CardTitle title="Priority Actions" subtitle="Recommended corrective steps"/>{[['Assign a retention policy','3 applications have no retention schedule','danger'],['Refresh consent records','5 consent records use an older version','warning'],['Complete annual reviewer training','Due in 6 days','info']].map(x=><div className="priority" key={x[0]}><span className={x[2]}><Icon name="alert" size={15}/></span><div><strong>{x[0]}</strong><p>{x[1]}</p></div><button onClick={()=>notify(`Opened: ${x[0]}`)}>Review</button></div>)}</Card></div>
    <div className="legal-note"><Icon name="shield"/><div><strong>{framework}</strong><p>This sample framework can help configure applicable DPDP-related privacy requirements. Legal applicability and compliance decisions must be reviewed by qualified professionals; VerifiAI does not guarantee legal compliance.</p></div></div>
    <Card className="table-card"><CardTitle title="Compliance Checklist" subtitle="Requirements for the selected framework"/><div className="table-wrap"><table><thead><tr><th>Requirement</th><th>Category</th><th>Status</th><th>Evidence</th><th>Last Reviewed</th><th>Action</th></tr></thead><tbody>{checks.map(x=><tr key={x[0]}><td><strong>{x[0]}</strong></td><td>{x[1]}</td><td><Badge tone={x[2]==='Passed'?'success':x[2]==='Warning'?'warning':'danger'}>{x[2]}</Badge></td><td className="id-cell">{x[3]}</td><td>{x[4]}</td><td><button className="table-action" onClick={()=>notify(`Reviewing ${x[0]}`)}>Review <Icon name="chevron" size={13}/></button></td></tr>)}</tbody></table></div></Card>
  </>
}

function Risk({ notify }: { notify:(s:string)=>void }) {
  const [open,setOpen]=useState(true)
  return <><PageHeader title="AI Risk Analysis" subtitle="Understand risk indicators and support informed reviewer decisions."><Button tone="secondary" icon="download">Export Analysis</Button></PageHeader>
    <div className="risk-hero"><Card className="overall-risk"><div><span className="eyebrow">OVERALL RISK SCORE</span><div className="big-risk"><strong>68</strong><span>/100</span></div><Badge tone="warning">Medium risk</Badge><p>Manual review recommended before approval.</p></div><div className="gauge"><div className="gauge-fill"/><span>68</span></div></Card>
      <Card><CardTitle title="Risk Distribution" subtitle="Across 1,284 applications"/><div className="bar-chart compact"><Bar label="Low risk" value={72} count="924" tone="green"/><Bar label="Medium risk" value={21} count="269" tone="amber"/><Bar label="High risk" value={7} count="91" tone="red"/></div></Card>
      <Card><CardTitle title="Reviewer Decision"/><p className="muted">AI indicators support, but do not replace, human judgment.</p><label className="field"><span>Override risk level</span><select><option>Keep Medium</option><option>Set Low</option><option>Set High</option></select></label><Button onClick={()=>notify('Reviewer decision saved')}>Save Decision</Button></Card></div>
    <div className="risk-content"><Card><CardTitle title="Risk Factors" subtitle="Signals contributing to this assessment"/>{[['Missing Information','Moderate',54,'warning'],['Document Inconsistency','High',86,'danger'],['Duplicate Submission','Low',18,'success'],['Compliance Issues','Moderate',61,'warning']].map(x=><div className="factor" key={x[0] as string}><div><strong>{x[0]}</strong><Badge tone={x[3] as Tone}>{x[1]}</Badge></div><div className="factor-bar"><i className={x[3] as string} style={{width:`${x[2]}%`}}/></div><span>{x[2]}</span></div>)}</Card>
      <Card className="explain"><div className="card-title"><div><h3>Explain Risk Score</h3><p>Transparent reasons behind each flag</p></div><button onClick={()=>setOpen(!open)}><Icon name="chevron"/></button></div>{open&&<div className="explain-body"><div><span className="num">1</span><p><strong>Legal name inconsistency (+28)</strong><small>A middle-name variance was detected across two documents. This can be benign and is not proof of fraud.</small></p></div><div><span className="num">2</span><p><strong>Incomplete consent metadata (+17)</strong><small>The timestamp is present, but the consent policy version is missing.</small></p></div><div><span className="num">3</span><p><strong>Recent address change (+9)</strong><small>Address proof was issued within the last 30 days.</small></p></div></div>}<div className="recommendation"><span>Recommended actions</span><ul><li>Confirm the applicant’s full legal name</li><li>Capture current consent policy version</li><li>Review original address proof</li></ul></div></Card></div>
    <Card><CardTitle title="Risk History" subtitle="How the score changed during validation"/><div className="timeline horizontal">{[['Submission received','32 · Low','10:32'],['OCR analysis complete','45 · Medium','10:35'],['Name mismatch detected','71 · High','10:36'],['Evidence reviewed','68 · Medium','11:08']].map((x,i)=><div key={x[0]}><span className={i===3?'current':''}/><strong>{x[0]}</strong><p>{x[1]}</p><small>{x[2]}</small></div>)}</div></Card>
  </>
}

function Reports() {
  return <><PageHeader title="Reports & Analytics" subtitle="Monitor verification performance, trends, and operational outcomes."><select className="framework"><option>Last 30 days</option><option>Last 90 days</option></select><Button icon="download">Export Report</Button></PageHeader>
    <div className="report-kpis">{[['Applications processed','4,892','+12.4%'],['Avg. verification time','4m 18s','-18.2%'],['Verification success rate','94.6%','+2.1%'],['Compliance performance','92.4%','+1.8%']].map((x,i)=><Card key={x[0]}><span>{x[0]}</span><strong>{x[1]}</strong><small className={i===1?'good':''}>{x[2]} vs previous period</small></Card>)}</div>
    <div className="reports-grid"><Card className="trend-card"><CardTitle title="Monthly Application Trends" subtitle="Received and verified applications"/><div className="legend"><span><i className="dot blue"/>Received</span><span><i className="dot cyan"/>Verified</span></div><LineChart/></Card><Card><CardTitle title="Application Categories" subtitle="Share of processed volume"/><div className="category-donut"><Donut value="38%" label="Vendor"/><div className="chart-list"><div><span><i className="dot blue"/>Vendor onboarding</span><b>38%</b></div><div><span><i className="dot cyan"/>Identity review</span><b>27%</b></div><div><span><i className="dot amber"/>Business license</span><b>21%</b></div><div><span><i className="dot gray"/>Other</span><b>14%</b></div></div></div></Card></div>
    <div className="reports-grid equal"><Card><CardTitle title="Risk Distribution" subtitle="Monthly comparison"/><div className="column-chart">{[64,72,58,81,74,89,78,92,84,88,96,86].map((v,i)=><div key={i}><span style={{height:`${v}%`}}/><small>{['Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May'][i]}</small></div>)}</div></Card><Card><CardTitle title="Verification Outcomes" subtitle="By document type"/>{[['Identity documents',96],['Address proofs',91],['Business certificates',88],['Tax documents',94]].map(x=><div className="outcome" key={x[0] as string}><div><span>{x[0]}</span><b>{x[1]}%</b></div><div><i style={{width:`${x[1]}%`}}/></div></div>)}</Card></div>
  </>
}

function Audit() {
  const [selected,setSelected]=useState<string|null>(null)
  const events=[['May 26, 2025 · 11:42 AM','Alex Morgan','Application approved','APP-2025-1284','Pending','Verified'],['May 26, 2025 · 11:18 AM','Priya Nair','Validation completed','APP-2025-1283','Draft','Pending'],['May 26, 2025 · 10:56 AM','System','Risk score updated','APP-2025-1282','Medium','High'],['May 26, 2025 · 10:32 AM','Maya Patel','Documents uploaded','APP-2025-1284','Incomplete','Submitted'],['May 26, 2025 · 9:47 AM','Daniel Kim','Changes requested','APP-2025-1279','Pending','Changes requested']]
  return <><PageHeader title="Audit Trail" subtitle="Review immutable records of user and system activity."><Button tone="secondary" icon="download">Export Log</Button></PageHeader>
    <Card className="toolbar-card"><div className="toolbar"><SearchBox placeholder="Search user, action, or application ID..."/><div className="filters"><button><Icon name="filter" size={16}/> Action type</button><button>Date range <Icon name="chevron" size={13}/></button><button>User <Icon name="chevron" size={13}/></button></div></div></Card>
    <Card className="table-card"><div className="table-summary"><span><strong>8,492</strong> recorded events</span><span className="secure"><Icon name="lock" size={14}/> Audit logging active</span></div><div className="table-wrap"><table><thead><tr><th>Timestamp</th><th>User</th><th>Action</th><th>Application ID</th><th>Previous Status</th><th>Updated Status</th><th></th></tr></thead><tbody>{events.map(x=><tr key={x[0]} className="click-row" onClick={()=>setSelected(x[2])}><td>{x[0]}</td><td><strong>{x[1]}</strong></td><td>{x[2]}</td><td className="id-cell">{x[3]}</td><td><Badge>{x[4]}</Badge></td><td><Badge tone={x[5]==='Verified'?'success':x[5]==='High'?'danger':'info'}>{x[5]}</Badge></td><td><Icon name="chevron" size={14}/></td></tr>)}</tbody></table></div></Card>
    {selected&&<div className="drawer-backdrop" onClick={()=>setSelected(null)}><aside className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><div><span className="eyebrow">AUDIT EVENT</span><h2>{selected}</h2></div><button onClick={()=>setSelected(null)}><Icon name="x"/></button></div><div className="event-icon"><Icon name="clock"/></div><div className="info-grid"><Info label="Timestamp" value="May 26, 2025 · 11:42:08 AM"/><Info label="Performed by" value="Alex Morgan"/><Info label="Application" value="APP-2025-1284"/><Info label="IP address" value="103.21.58.•••"/></div><div className="event-description"><strong>Event description</strong><p>The application was approved after manual review. All required identity, document, and compliance checks were completed.</p></div><div className="change-box"><span>Pending review</span><b>→</b><span>Verified</span></div><small className="hash">Event hash · 8e74c1…f02a · Integrity verified</small></aside></div>}
  </>
}

function Settings({ notify }: { notify:(s:string)=>void }) {
  const [section,setSection]=useState('User Profile')
  const sections=[['User Profile','user'],['Notifications','bell'],['Application Categories','files'],['Validation Rules','scan'],['Compliance Rules','shield'],['Theme Preferences','grid'],['Reviewer Assignment','brain']]
  return <><PageHeader title="Settings" subtitle="Manage your workspace, validation preferences, and account."/><div className="settings-layout"><Card className="settings-nav">{sections.map(x=><button className={section===x[0]?'active':''} onClick={()=>setSection(x[0])} key={x[0]}><Icon name={x[1]}/>{x[0]}<Icon name="chevron" size={13}/></button>)}</Card><div className="stack">
    {section==='User Profile'?<><Card><CardTitle title="User Profile" subtitle="Update your personal details and profile image"/><div className="profile-edit"><span className="avatar-xl">AM</span><div><Button tone="secondary">Change photo</Button><p>JPG or PNG. Maximum 2 MB.</p></div></div><div className="form-grid"><Field label="Full Name" value="Alex Morgan"/><Field label="Email Address" value="alex.morgan@verifiai.com"/><Field label="Job Title" value="Senior Verification Analyst"/><Field label="Phone Number" value="+91 99876 54321"/></div></Card><Card><CardTitle title="Workspace & Role"/><div className="info-grid"><Info label="Workspace" value="VerifiAI Demo Organization"/><Info label="Role" value="Verification Analyst"/><Info label="Member since" value="January 12, 2025"/><Info label="Last sign in" value="Today, 8:42 AM"/></div></Card></>:<SettingsSection name={section}/>}
    <div className="settings-save"><Button tone="secondary">Discard Changes</Button><Button onClick={()=>notify(`${section} settings saved`)}>Save Changes</Button></div>
  </div></div></>
}

function SettingsSection({name}:{name:string}) {
  const rows=name==='Notifications'?['Application assigned to me','High-risk case detected','Document verification completed','Compliance requirement failed','Weekly performance summary']:name==='Theme Preferences'?['Compact table rows','Reduced motion','High contrast badges']:name==='Reviewer Assignment'?['Auto-assign by workload','Route high-risk cases to senior reviewers','Allow reassignment by analysts']:name==='Application Categories'?['Vendor Onboarding','Business License','Identity Review','Grant Application']:name==='Validation Rules'?['Run OCR on upload','Cross-document name matching','Duplicate document detection','File integrity analysis']:['Require valid consent record','Enforce retention schedule','Flag expired identity documents','Require reviewer separation']
  return <Card><CardTitle title={name} subtitle={`Configure ${name.toLowerCase()} for your workspace.`}/><div className="setting-rows">{rows.map((x,i)=><div className="setting-row" key={x}><div><strong>{x}</strong><p>{i%2?'Apply this rule to all active applications.':'Recommended for enterprise verification workflows.'}</p></div><label className="switch"><input type="checkbox" defaultChecked={i<3}/><span/></label></div>)}</div>{(name==='Application Categories'||name==='Validation Rules'||name==='Compliance Rules')&&<Button tone="secondary" icon="plus">Add {name.slice(0,-1)}</Button>}</Card>
}

function App() {
  const [page,setPage]=useState<Page>('dashboard')
  const [mobile,setMobile]=useState(false)
  const [profile,setProfile]=useState(false)
  const [notifications,setNotifications]=useState(false)
  const [selectedApp,setSelectedApp]=useState<string|null>(null)
  const [toast,setToast]=useState('')
  const notify=(s:string)=>{setToast(s);setTimeout(()=>setToast(''),2600)}
  const navigate=(p:Page)=>{setPage(p);setSelectedApp(null);setMobile(false);window.scrollTo(0,0)}
  const pageLabel=useMemo(()=>selectedApp?'Application Details':nav.find(n=>n.id===page)?.label||'Dashboard',[page,selectedApp])
  return <div className="app-shell">
    <aside className={`sidebar ${mobile?'open':''}`}><div className="brand"><span className="brand-mark"><Icon name="shield" size={25}/></span><div><strong>VerifiAI</strong><small>Intelligent Verification Platform</small></div></div><nav>{nav.map(n=><button className={page===n.id&&!selectedApp?'active':''} onClick={()=>navigate(n.id)} key={n.id}><Icon name={n.icon}/><span>{n.label}</span>{n.id==='applications'&&<em>218</em>}</button>)}</nav><div className="sidebar-footer"><div className="usage"><div><span>Monthly verifications</span><b>1,284 / 2,000</b></div><div><i/></div><small>64% of plan used</small></div><button className="support"><Icon name="help"/><div><strong>Need help?</strong><small>Visit Support Center</small></div></button></div></aside>
    {mobile&&<div className="mobile-overlay" onClick={()=>setMobile(false)}/>}
    <div className="main-shell"><header className="topbar"><button className="menu-toggle" onClick={()=>setMobile(!mobile)}>☰</button><div className="breadcrumb"><span>VerifiAI</span><b>/</b><strong>{pageLabel}</strong></div><div className="top-actions"><SearchBox placeholder="Search applications, documents..."/><div className="popover-wrap"><button className="icon-btn" onClick={()=>setNotifications(!notifications)}><Icon name="bell"/><i/></button>{notifications&&<div className="popover notification-pop"><div><strong>Notifications</strong><button>Mark all read</button></div><p><span className="alert-dot"/><b>High-risk case detected</b><small>APP-2025-1282 · 12 min ago</small></p><p><span className="info-dot"/><b>Verification completed</b><small>APP-2025-1284 · 34 min ago</small></p></div>}</div><button className="icon-btn"><Icon name="help"/></button><div className="profile-wrap"><button className="profile" onClick={()=>setProfile(!profile)}><span>AM</span><div><strong>Alex Morgan</strong><small>Verification Analyst</small></div><Icon name="chevron" size={13}/></button>{profile&&<div className="popover profile-pop"><button onClick={()=>navigate('settings')}><Icon name="user"/>My profile</button><button><Icon name="settings"/>Workspace settings</button><hr/><button>Sign out</button></div>}</div></div></header>
      <main>{selectedApp?<ApplicationDetail id={selectedApp} onBack={()=>setSelectedApp(null)} notify={notify}/>:page==='dashboard'?<Dashboard navigate={navigate} openApplication={setSelectedApp}/>:page==='applications'?<Applications navigate={navigate} openApplication={setSelectedApp}/>:page==='new'?<NewApplication navigate={navigate} notify={notify}/>:page==='document'?<DocumentVerification notify={notify}/>:page==='compliance'?<Compliance notify={notify}/>:page==='risk'?<Risk notify={notify}/>:page==='reports'?<Reports/>:page==='audit'?<Audit/>:<Settings notify={notify}/>}</main>
    </div>{toast&&<div className="toast"><span><Icon name="check" size={15}/></span>{toast}</div>}
  </div>
}

export default App
